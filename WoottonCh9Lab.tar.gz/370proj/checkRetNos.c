/* checkRetNos.c
* three functions that return an integer
* Chris Wootton 
*/

#include <stdio.h>
int positiveNumber (void);
int negativeNumber(void);
int maxNumber(void);

int main()
{
 int x;

 x = positiveNumber();
 printf("Positive constant is: %i, ", x);

 x = negativeNumber();
 printf("Negative constant is: %i, ", x);

 x = maxNumber();
 printf("Maximum number is: %i.\n", x);

 return 0;
}



