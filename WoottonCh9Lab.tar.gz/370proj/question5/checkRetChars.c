/*
 * checkRetChars.c
 * calls three assembly language functions and
 * prints their return characters.
 *
 * 2017-09-29: Bob Plantz
 * Modified by Chris Wootton
 */

#include <stdio.h>
int A(void);
int z(void);
int hashtag(void);

int main()
{
    char aCharacter;

    aCharacter = A();
    printf("Brought to you by the letters: %c, ", aCharacter);

    aCharacter = z();
    printf("%c, ", aCharacter);

    aCharacter = hashtag();
    printf("and %c.\n", aCharacter);

    return 0;
}


